# Location Alarm
This app lets you set-up an alarm that wakes you up when your destination is approaching.

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/4765c3533cdd4fbc8d692aa93eae9738)](https://www.codacy.com/app/Kailash23/location-alarm-app?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Kailash23/location-alarm-app&amp;utm_campaign=Badge_Grade)

